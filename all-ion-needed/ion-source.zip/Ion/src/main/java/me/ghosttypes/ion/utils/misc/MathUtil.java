package me.ghosttypes.ion.utils.misc;

public class MathUtil {

    public static int intToTicks(int i) {
        return i * 20;
    }

    public static int ticksToInt(int i) {
        return i / 20;
    }
}
