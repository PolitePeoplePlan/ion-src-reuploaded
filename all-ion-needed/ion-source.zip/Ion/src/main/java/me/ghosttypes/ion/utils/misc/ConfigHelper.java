package me.ghosttypes.ion.utils.misc;

import me.ghosttypes.ion.Ion;
import meteordevelopment.meteorclient.MeteorClient;
import org.apache.commons.io.FileUtils;

import java.io.File;


public class ConfigHelper {

    public static File backupFolder = new File(Ion.MODFOLDER, "backup");

    public static void backup() {
        try {
            FileUtils.copyDirectory(MeteorClient.FOLDER, backupFolder);
        } catch (Exception e) {
            Ion.log("Error backing up current settings: " + e);
        }
    }

}
