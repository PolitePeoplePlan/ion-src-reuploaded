package me.ghosttypes.ion.modules.autopvp;

import me.ghosttypes.ion.utils.combat.HoleUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Random;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class HoleParser {

    public static BlockPos getSafeHole(int rangeH, int rangeV) {
        List<BlockPos> holes = HoleUtil.getHoles(mc.player.getBlockPos(), rangeH, rangeV);
        for (PlayerEntity player : mc.world.getPlayers()) holes.removeIf(hole -> hole.equals(player.getBlockPos()));
        holes.removeIf(HoleUtil::isHoleObstructed);
        //holes.removeIf(hole -> mc.player.getBlockPos().equals(hole));
        if (holes.isEmpty()) return null;
        if (holes.size() > 1) return holes.get(new Random().nextInt(holes.size()));
        return holes.get(0);
    }

    public static BlockPos getHoleNearTarget(PlayerEntity target, int rangeH, int rangeV) {
        List<BlockPos> holes = HoleUtil.getHoles(target.getBlockPos(), rangeH, rangeV);
        for (PlayerEntity player : mc.world.getPlayers()) holes.removeIf(hole -> hole.equals(player.getBlockPos()));
        holes.removeIf(HoleUtil::isHoleObstructed);
        //holes.removeIf(hole -> mc.player.getBlockPos().equals(hole));
        if (holes.isEmpty()) return null;
        if (holes.size() > 1) return holes.get(new Random().nextInt(holes.size()));
        return holes.get(0);
    }

}
