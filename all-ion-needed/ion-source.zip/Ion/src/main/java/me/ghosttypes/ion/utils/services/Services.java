package me.ghosttypes.ion.utils.services;

import me.ghosttypes.ion.Ion;
import me.ghosttypes.ion.utils.OutgoingMessages;
import me.ghosttypes.ion.utils.stats.Globals;

public class Services {

    public static void startServices() {
        Ion.log("Starting services.");
        DigitalWellbeing.init();
        DiscordHelper.init();
        //OnlineUsers.init(); TODO: Temp auth fix, restore after
        SpotifyHelper.init();
        OutgoingMessages.init();
        Globals.init();
    }

    public static void stopServices() {
        Ion.log("Stopping services.");
        DigitalWellbeing.shutdown();
        DiscordHelper.shutdown();
        //OnlineUsers.shutdown();
        SpotifyHelper.shutdown();
        Globals.shutdown();
    }
}
