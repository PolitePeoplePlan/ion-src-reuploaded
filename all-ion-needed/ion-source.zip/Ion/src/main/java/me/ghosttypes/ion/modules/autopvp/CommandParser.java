package me.ghosttypes.ion.modules.autopvp;

import me.ghosttypes.ion.Ion;
import net.minecraft.entity.player.PlayerEntity;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class CommandParser {


    public static String[] parseCommand(String command) {
        command = command.stripLeading(); // remove spaces from the start of the command
        if (command.startsWith("attack")) { // auto pvp command (follow + attack the target)
            try {
                String playerName = command.split("attack ")[1]; // parse player name
                if (getPlayerFromName(playerName) != null) return new String[]{"follow", playerName}; // confirm its a valid player
                return new String[]{"error", "target not found"};
            } catch (Exception e) {
                Ion.log("PvP Bot | Attack Command | Error: " + e);
                return new String[]{"error", "Invalid syntax"};
            }
        }
        return new String[]{"error", "Unknown or invalid command"};
    }

    public static PlayerEntity getPlayerFromName(String playerName) {
        for (PlayerEntity p : mc.world.getPlayers()) if (p.getEntityName().equalsIgnoreCase(playerName)) return p;
        return null;
    }

}
