package me.ghosttypes.ion.modules.combat;

import me.ghosttypes.ion.modules.hud.visual.NotificationsHUD;
import me.ghosttypes.ion.modules.render.Notifications;
import me.ghosttypes.ion.utils.Categories;
import me.ghosttypes.ion.utils.Wrapper;
import me.ghosttypes.ion.utils.player.AutomationUtils;
import me.ghosttypes.ion.utils.player.InvUtil;
import me.ghosttypes.ion.utils.world.Loader;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.AbstractButtonBlock;
import net.minecraft.block.AbstractPressurePlateBlock;
import net.minecraft.block.Block;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;


public class BurrowBreaker extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder().name("range").description("Max targeting range.").defaultValue(4).min(0).sliderMax(5).build());
    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder().name("rotate").description("Face the burrow block while mining.").defaultValue(true).build());
    private final Setting<Integer> rotatePrio = sgGeneral.add(new IntSetting.Builder().name("rotate-priority").description("Rotation priority.").defaultValue(50).min(1).max(100).build());
    private final Setting<Boolean> usePacketMine = sgGeneral.add(new BoolSetting.Builder().name("packet-mine").description("Hide mining progress on the target block.").defaultValue(true).build());
    private final Setting<Boolean> preventAfter = sgGeneral.add(new BoolSetting.Builder().name("prevent-after").description("Prevent the target from placing another burrow block in their current hole.").defaultValue(false).build());
    private final Setting<me.ghosttypes.ion.modules.render.Notifications.mode> notifyMode = sgGeneral.add(new EnumSetting.Builder<Notifications.mode>().name("notification-mode").description("How notifications are displayed.").defaultValue(me.ghosttypes.ion.modules.render.Notifications.mode.Chat).build());

    private PlayerEntity target;
    private boolean sentPacketMine;
    private boolean alertedTarget;
    private boolean wasBurrowed;

    public BurrowBreaker() {
        super(Categories.Combat, "burrow-breaker", "Automatically destroy target's burrow block.");
    }

    @Override
    public void onActivate() {
        Loader.moduleAuth();
        target = null;
        sentPacketMine = false;
        alertedTarget = false;
        wasBurrowed = false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        FindItemResult pickSlot = InvUtil.findPick();
        if (!pickSlot.found()) {
            notify("No pickaxe in hotbar!");
            toggle();
            return;
        }
        if (target == null && TargetUtils.getPlayerTarget(range.get(), SortPriority.LowestDistance) == null) {
            notify("No burrowed targets in range!");
            toggle();
            return;
        }
        target = TargetUtils.getPlayerTarget(range.get(), SortPriority.LowestDistance);
        if (target == null) return;
        if (AutomationUtils.isBurrowed(target, true)) {
            wasBurrowed = true;
            BlockPos burrowBlock = target.getBlockPos();
            if (!alertedTarget) {
                notify("Breaking " + target.getEntityName() + "'s burrow!");
                alertedTarget = true;
            }
            Wrapper.updateSlot(pickSlot.getSlot());
            if (usePacketMine.get() && !sentPacketMine) {
                AutomationUtils.doPacketMine(burrowBlock, rotate.get(), rotatePrio.get());
                sentPacketMine = true;
            } else { AutomationUtils.doRegularMine(burrowBlock, rotate.get(), rotatePrio.get()); }
            return;
        }
        if (!AutomationUtils.isBurrowed(target, true) && wasBurrowed) {
            notify("Broke " + target.getEntityName() + "'s burrow!");
            if (preventAfter.get()) {
                FindItemResult floorBlock = InvUtils.findInHotbar(itemStack -> Block.getBlockFromItem(itemStack.getItem()) instanceof AbstractPressurePlateBlock || Block.getBlockFromItem(itemStack.getItem()) instanceof AbstractButtonBlock);
                if (!floorBlock.found()) {
                    notify("No buttons or plates in hotbar, cannot prevent re-burrow.");
                    toggle();
                }
                BlockUtils.place(target.getBlockPos(), floorBlock, true, 0, false);
                notify("Blocked " + target.getEntityName() + " from re-burrowing!");
            }
            toggle();
        }
    }

    private void notify(String msg) {
        String title = "[" + this.name + "] ";
        switch (notifyMode.get()) {
            case Chat -> info(msg);
            case Hud -> NotificationsHUD.addNotification(title + msg);
        }
    }
}
