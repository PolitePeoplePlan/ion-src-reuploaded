package me.ghosttypes.ion.modules.autopvp;

import baritone.api.BaritoneAPI;
import baritone.api.pathing.goals.GoalBlock;
import me.ghosttypes.ion.utils.world.BlockHelper;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.movement.Blink;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class Pathing {

    public static boolean isPathing = false;

    public enum HoleType {
        Obby,
        Bedrock,
        Both
    }

    public static final ArrayList<Vec3d> surroundPos = new ArrayList<>() {{
        add(new Vec3d(1, 0, 0));
        add(new Vec3d(-1, 0, 0));
        add(new Vec3d(0, 0, 1));
        add(new Vec3d(0, 0, -1));
    }};

    // Stop any baritone pathing
    public static void stopPathing() {
        isPathing = false;
        //BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath(new GoalBlock(null)); crashes
        BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().cancelEverything(); // proper way
    }
    // Stop any baritone entity following
    public static void stopFollowing() {
        BaritoneAPI.getProvider().getPrimaryBaritone().getFollowProcess().cancel();
    }


    public static void pathToBlock(BlockPos pos) {
        BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath(new GoalBlock(pos));
        isPathing = true;
    }


    public static boolean canPathToPlayer(PlayerEntity player, int maxDistance) {
        return mc.player.distanceTo(player) <= maxDistance;
    }

    public static BlockPos getHoleNearPlayer(PlayerEntity player, int radius, HoleType holeType, boolean onlyEmpty) {
        List<BlockPos> holes = getHoles(player.getBlockPos(), radius, holeType, onlyEmpty);
        if (holes.isEmpty()) return null;
        return holes.get(0);
    }

    public static List<BlockPos> getHoles(BlockPos startingPos, int radius, HoleType holeType, boolean onlyEmpty) {
        List<BlockPos> blocks = BlockHelper.getSphere(startingPos, radius, radius);
        blocks.removeIf(block -> !isValidHole(block, holeType));
        if (onlyEmpty) {
            List<BlockPos> playerPoses = getNearbyPlayerPos(startingPos, radius);
            blocks.removeIf(playerPoses::contains);
        }
        return blocks;
    }

    public static List<BlockPos> getNearbyPlayerPos(BlockPos startingPos, int radius) {
        ArrayList<BlockPos> poses = new ArrayList<>();
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof PlayerEntity) continue;
            if (BlockHelper.distanceBetween(startingPos, entity.getBlockPos()) <= radius) poses.add(entity.getBlockPos());
        }
        return poses;
    }

    public static boolean isValidHole(BlockPos hole, HoleType holeType) {
        boolean valid = true;
        switch (holeType) {
            case Both -> valid = isBothHole(hole);
            case Obby -> valid = isObbyHole(hole);
            case Bedrock -> valid = isBedrockHole(hole);
        }
        return valid;
    }

    public static boolean isBedrockHole(BlockPos hole) {
        for (Vec3d b : surroundPos) {
            BlockPos bb = hole.add(b.x, b.y, b.z);
            if (BlockHelper.getBlock(bb) != Blocks.BEDROCK) return false;
        }
        return true;
    }

    public static boolean isObbyHole(BlockPos hole) {
        for (Vec3d b : surroundPos) {
            BlockPos bb = hole.add(b.x, b.y, b.z);
            if (BlockHelper.getBlock(bb) != Blocks.OBSIDIAN) return false;
        }
        return true;
    }

    public static boolean isBothHole(BlockPos hole) {
        return isBedrockHole(hole) || isObbyHole(hole);
    }
}
