package me.ghosttypes.ion.modules.render;

import me.ghosttypes.ion.utils.Categories;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

public class CsgoESP extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>().name("shape-mode").description("The shape mode.").defaultValue(ShapeMode.Both).build());
    public final Setting<SettingColor> sideColor = sgGeneral.add(new ColorSetting.Builder().name("side-color").description("The side color.").defaultValue(new SettingColor(114, 11, 135,75)).build());
    public final Setting<SettingColor> lineColor = sgGeneral.add(new ColorSetting.Builder().name("line-color").description("The line color.").defaultValue(new SettingColor(114, 11, 135)).build());


    public CsgoESP() { super(Categories.Misc, "pop-esp", "Render ESP where players pop."); }
}
