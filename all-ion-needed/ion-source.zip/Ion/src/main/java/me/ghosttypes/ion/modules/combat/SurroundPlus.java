package me.ghosttypes.ion.modules.combat;

import me.ghosttypes.ion.modules.hud.visual.NotificationsHUD;
import me.ghosttypes.ion.modules.render.Notifications;
import me.ghosttypes.ion.utils.Categories;
import me.ghosttypes.ion.utils.stats.Globals;
import me.ghosttypes.ion.utils.player.AutomationUtils;
import me.ghosttypes.ion.utils.world.BlockHelper;
import me.ghosttypes.ion.utils.world.Loader;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.AbstractButtonBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SurroundPlus extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgProtect = settings.createGroup("Protect");
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> blockPerTick = sgGeneral.add(new IntSetting.Builder().name("blocks-per-tick").description("Block placements per tick.").defaultValue(4).min(1).sliderMax(10).build());
    private final Setting<Boolean> useDouble = sgGeneral.add(new BoolSetting.Builder().name("double").description("Place at your feet and head.").defaultValue(false).build());
    private final Setting<Boolean> extra = sgGeneral.add(new BoolSetting.Builder().name("extra").description("Place extra surround blocks.").defaultValue(false).build());
    private final Setting<Boolean> russian = sgGeneral.add(new BoolSetting.Builder().name("russian").description("Russian surround.").defaultValue(false).build());
    private final Setting<Boolean> antiFall = sgGeneral.add(new BoolSetting.Builder().name("anti-fall").description("Prevents the block you are standing on from being broken.").defaultValue(false).build());
    private final Setting<Boolean> groundOnly = sgGeneral.add(new BoolSetting.Builder().name("only-on-ground").description("Only activate when you're on the ground.").defaultValue(true).build());
    private final Setting<Boolean> sneakOnly = sgGeneral.add(new BoolSetting.Builder().name("require-sneak").description("Only activate while you're sneaking.").defaultValue(false).build());
    private final Setting<Boolean> disableAfter = sgGeneral.add(new BoolSetting.Builder().name("toggle-after").description("Disable after the surround is complete.").defaultValue(false).build());
    private final Setting<Boolean> centerPlayer = sgGeneral.add(new BoolSetting.Builder().name("center").description("Center you before starting the surround.").defaultValue(true).build());
    private final Setting<Boolean> disableJump = sgGeneral.add(new BoolSetting.Builder().name("toggle-on-jump").description("Disable if you jump.").defaultValue(true).build());
    private final Setting<Boolean> disableYchange = sgGeneral.add(new BoolSetting.Builder().name("toggle-on-y-change").description("Disable if your Y coord changes.").defaultValue(true).build());
    private final Setting<Boolean> rotation = sgGeneral.add(new BoolSetting.Builder().name("rotate").description("Rotate on block interactions.").defaultValue(false).build());
    private final Setting<List<Block>> blocks = sgGeneral.add(new BlockListSetting.Builder().name("block").description("What blocks to use for surround.").defaultValue(Collections.singletonList(Blocks.OBSIDIAN)).filter(this::blockFilter).build());
    private final Setting<me.ghosttypes.ion.modules.render.Notifications.mode> notifyMode = sgGeneral.add(new EnumSetting.Builder<Notifications.mode>().name("notification-mode").description("How notifications are displayed.").defaultValue(me.ghosttypes.ion.modules.render.Notifications.mode.Chat).build());

    private final Setting<Boolean> protect = sgProtect.add(new BoolSetting.Builder().name("protect").description("Protect yourself from surround break/hold.").defaultValue(false).build());
    private final Setting<Boolean> protectClamp = sgProtect.add(new BoolSetting.Builder().name("clamp").description("Attempt to protect from buttons/string breaking your surround.").defaultValue(false).build());
    private final Setting<Integer> clampPt = sgGeneral.add(new IntSetting.Builder().name("clamp-blocks-per-tick").description("How many blocks clamp can place per tick.").defaultValue(3).min(1).sliderMax(10).build());
    private final Setting<Integer> protectDelay = sgProtect.add(new IntSetting.Builder().name("delay").description("Delay between trying to break dangerous crystals.").defaultValue(2).min(1).sliderMax(10).build());
    private final Setting<Integer> protectMax = sgProtect.add(new IntSetting.Builder().name("max-tries").description("How many times to try protecting your surround before disabling.").defaultValue(5).min(1).sliderMax(10).build());

    private final Setting<Boolean> render = sgRender.add(new BoolSetting.Builder().name("render").description("Renders where the surround will be placed.").defaultValue(true).build());
    private final Setting<Boolean> alwaysRender = sgRender.add(new BoolSetting.Builder().name("always").description("Render the surround blocks after they are placed.").defaultValue(false).visible(render :: get).build());
    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>().name("shape-mode").description("How the shapes are rendered.").defaultValue(ShapeMode.Both).build());
    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder().name("side-color").description("The side color.").defaultValue(new SettingColor(15, 255, 211,75)).build());
    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder().name("line-color").description("The line color.").defaultValue(new SettingColor(15, 255, 211)).build());

    private final ArrayList<Vec3d> clamp = new ArrayList<>() {{
        add(new Vec3d(1, 0, 0));
        add(new Vec3d(-1, 0, 0));
        add(new Vec3d(0, 0, 1));
        add(new Vec3d(0, 0, -1));
        add(new Vec3d(0, 1, 0));
    }};

    private final ArrayList<Vec3d> surr = new ArrayList<>() {{
        add(new Vec3d(1, 0, 0));
        add(new Vec3d(-1, 0, 0));
        add(new Vec3d(0, 0, 1));
        add(new Vec3d(0, 0, -1));
    }};

    private final ArrayList<Vec3d> surrDouble = new ArrayList<>() {{
        add(new Vec3d(1, 1, 0));
        add(new Vec3d(-1, 1, 0));
        add(new Vec3d(0, 1, 1));
        add(new Vec3d(0, 1, -1));
    }};


    private int protectTimer, protectTries;
    private boolean doProtect;

    public SurroundPlus() {
        super(Categories.Combat, "surround-plus", "Surround v2.");
    }

    @Override
    public void onActivate() {
        Loader.moduleAuth();
        if (centerPlayer.get()) PlayerUtils.centerPlayer();
        protectTimer = 0;
        doProtect = true;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        int bpt = 0;
        int cpt = 0;
        if ((disableJump.get() && (mc.options.keyJump.isPressed() || mc.player.input.jumping)) || (disableYchange.get() && mc.player.prevY < mc.player.getY())) { toggle(); return; }
        if (groundOnly.get() && !mc.player.isOnGround()) return;
        if (sneakOnly.get() && !mc.options.keySneak.isPressed()) return;

        // This is broken, might need to send a jump packet or some shit but dont care to fix it rn
        //TODO Fix this eventually
        if (antiFall.get() && BlockHelper.getBlock(mc.player.getBlockPos().down()) == Blocks.AIR) {
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY() + 1, mc.player.getZ(), false));
            BlockUtils.place(mc.player.getBlockPos().down(), InvUtils.findInHotbar(itemStack -> blocks.get().contains(Block.getBlockFromItem(itemStack.getItem()))), rotation.get(), 100, true);
            bpt++;
        }

        if (BlockHelper.isVecComplete(getSurrDesign())) {
            if (disableAfter.get()) {
                notify("Surround Complete.");
                toggle();
            }
            // we should only do protection after the base surround design is complete, to avoid breaking crystals placed in a city
            // or getting stuck trying to finish the surround
            if (protect.get() && protectTimer <= 0 && doProtect) {
                protectTimer = protectDelay.get();
                for (Entity entity : mc.world.getEntities()) {
                    if (entity instanceof EndCrystalEntity) {
                        BlockPos crystalPos = entity.getBlockPos();
                        if (isDangerousCrystal(crystalPos)) {
                            mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(entity, mc.player.isSneaking()));
                            mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                            protectTries++;
                            if (protectTries >= protectMax.get()) doProtect = false;
                            break;
                        }
                    }
                }
            } else {
                protectTimer--;
            }
        } else {
            // build the base surround design
            BlockPos ppos = mc.player.getBlockPos();
            for (Vec3d b : getSurrDesign()) {
                if (bpt >= blockPerTick.get()) return;
                BlockPos bb = ppos.add(b.x, b.y, b.z);
                if (BlockHelper.getBlock(bb) == Blocks.AIR) {
                    BlockUtils.place(bb, InvUtils.findInHotbar(itemStack -> blocks.get().contains(Block.getBlockFromItem(itemStack.getItem()))), rotation.get(), 100, true);
                    bpt++;
                }
            }
        }
        // build the extra surround design
        if (extra.get()) {
            for (BlockPos bb : getExtraBlocks()) {
                if (bpt >= blockPerTick.get()) return;
                if (BlockHelper.getBlock(bb) == Blocks.AIR) {
                    BlockUtils.place(bb, InvUtils.findInHotbar(itemStack -> blocks.get().contains(Block.getBlockFromItem(itemStack.getItem()))), rotation.get(), 100, true);
                    bpt++;
                }
            }
        }
        // build the russian surround design
        if (russian.get()) {
            for (BlockPos bb : getRussianBlocks()) {
                if (bpt >= blockPerTick.get()) return;
                if (BlockHelper.getBlock(bb) == Blocks.AIR) {
                    BlockUtils.place(bb, InvUtils.findInHotbar(itemStack -> blocks.get().contains(Block.getBlockFromItem(itemStack.getItem()))), rotation.get(), 100, true);
                    bpt++;
                }
            }
        }
        // only handle clamp after the entire surround design is complete
        if (protect.get() && protectClamp.get()) {
            BlockPos clampPos = getClampPos();
            if (clampPos != null) {
                for (Vec3d b : clamp) {
                    if (cpt >= clampPt.get()) break;
                    BlockPos bb = clampPos.add(b.x, b.y, b.z);
                    if (BlockHelper.getBlock(bb) == Blocks.AIR) BlockUtils.place(bb, InvUtils.findInHotbar(itemStack -> blocks.get().contains(Block.getBlockFromItem(itemStack.getItem()))), rotation.get(), 100, false);
                    cpt++;
                }
            }
        }
    }

    private ArrayList<BlockPos> getExtraBlocks() {
        ArrayList<BlockPos> posi = new ArrayList<>();
        BlockPos pp = mc.player.getBlockPos();
        if (Globals.isLegacyModeActive()) {
            posi.add(pp.north(2).down());
            posi.add(pp.south(2).down());
            posi.add(pp.east(2).down());
            posi.add(pp.west(2).down());
        }
        posi.add(pp.north(2));
        posi.add(pp.south(2));
        posi.add(pp.east(2));
        posi.add(pp.west(2));
        return posi;
    }

    private ArrayList<BlockPos> getRussianBlocks() {
        BlockPos pp = mc.player.getBlockPos();
        ArrayList<BlockPos> posi = new ArrayList<>();
        if (Globals.isLegacyModeActive()) {
            posi.add(pp.north().east().down());
            posi.add(pp.east().south().down());
            posi.add(pp.south().west().down());
            posi.add(pp.west().north().down());
        }
        posi.add(pp.north().east());
        posi.add(pp.east().south());
        posi.add(pp.south().west());
        posi.add(pp.west().north());
        return posi;
    }


    private ArrayList<Vec3d> getSurrDesign() {
        ArrayList<Vec3d> surrDesign = new ArrayList<>();
        if (Globals.isLegacyModeActive()) for (Vec3d s : surr) surrDesign.add(s.add(0, -1 , 0));
        surrDesign.addAll(surr);
        if (useDouble.get()) {
            if (Globals.isLegacyModeActive()) for (Vec3d s : surrDouble) surrDesign.add(s.add(0 , -1 , 0));
            surrDesign.addAll(surrDouble);
        }
        return surrDesign;
    }

    private boolean isDangerousCrystal(BlockPos bp) {
        BlockPos ppos = mc.player.getBlockPos();
        for (Vec3d b : getSurrDesign()) {
            BlockPos bb = ppos.add(b.x, b.y, b.z);
            if (!bp.equals(bb) && BlockHelper.distanceBetween(bb, bp) <= 2) return true;
        }
        return false;
    }

    private BlockPos getClampPos() {
        BlockPos ppos = mc.player.getBlockPos();
        for (Vec3d b : getSurrDesign()) {
            BlockPos bb = ppos.add(b.x, b.y, b.z);
            if (BlockHelper.getBlock(bb) instanceof AbstractButtonBlock || AutomationUtils.isWeb(bb)) return bb;
        }
        return null;
    }

    private boolean blockFilter(Block block) {
        return block == Blocks.OBSIDIAN ||
                block == Blocks.CRYING_OBSIDIAN ||
                block == Blocks.NETHERITE_BLOCK ||
                block == Blocks.ENDER_CHEST ||
                block == Blocks.RESPAWN_ANCHOR;
    }

    private void notify(String msg) {
        String title = "[" + this.name + "] ";
        switch (notifyMode.get()) {
            case Chat -> info(msg);
            case Hud -> NotificationsHUD.addNotification(title + msg);
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (render.get()) {
            BlockPos ppos = mc.player.getBlockPos();
            for (Vec3d b: getSurrDesign()) {
                BlockPos bb = ppos.add(b.x, b.y, b.z);
                if (BlockHelper.getBlock(bb) == Blocks.AIR) event.renderer.box(bb, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
                if (alwaysRender.get()) event.renderer.box(bb, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
            }
        }
    }

}

