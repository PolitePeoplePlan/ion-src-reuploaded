package me.ghosttypes.ion.modules.render;

import me.ghosttypes.ion.utils.Categories;
import me.ghosttypes.ion.utils.misc.MathUtil;
import me.ghosttypes.ion.utils.player.PlayerUtil;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PopESP extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAscend = settings.createGroup("Ascend");
    private final SettingGroup sgFade = settings.createGroup("Fade");
    private final SettingGroup sgPopText = settings.createGroup("PopText");

    private final Setting<Boolean> debug = sgGeneral.add(new BoolSetting.Builder().name("debug").description("Spam chat with shit you won't understand.").defaultValue(false).build());
    private final Setting<Boolean> deleteOld = sgGeneral.add(new BoolSetting.Builder().name("delete-old").description("Only allow one ESP per player.").defaultValue(false).build());
    private final Setting<Integer> renderTime = sgGeneral.add(new IntSetting.Builder().name("render-time").description("How long the ESP is rendered in seconds.").defaultValue(2).min(1).build());
    public final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>().name("shape-mode").description("The shape mode.").defaultValue(ShapeMode.Both).build());
    public final Setting<SettingColor> sideColor = sgGeneral.add(new ColorSetting.Builder().name("side-color").description("The side color.").defaultValue(new SettingColor(114, 11, 135,75)).build());
    public final Setting<SettingColor> lineColor = sgGeneral.add(new ColorSetting.Builder().name("line-color").description("The line color.").defaultValue(new SettingColor(114, 11, 135)).build());
    // Ascend
    private final Setting<Boolean> ascend = sgAscend.add(new BoolSetting.Builder().name("ascend").defaultValue(false).build());
    private final Setting<Double> ascendFactor = sgAscend.add(new DoubleSetting.Builder().name("ascend-factor").defaultValue(0.1).min(0).build());
    private final Setting<Integer> ascendTicks = sgAscend.add(new IntSetting.Builder().name("ascend-ticks").defaultValue(11).min(1).build());
    // Fade
    private final Setting<Boolean> fade = sgFade.add(new BoolSetting.Builder().name("fade").defaultValue(false).build());
    private final Setting<Integer> fadeFactor = sgFade.add(new IntSetting.Builder().name("fade-factor").defaultValue(1).min(1).build());
    private final Setting<Integer> fadeTicks = sgFade.add(new IntSetting.Builder().name("fade-ticks").defaultValue(8).min(1).build());
    // PopText
    private final Setting<Boolean> renderPopText = sgPopText.add(new BoolSetting.Builder().name("render-pop-count").description("Display how many times the user popped.").defaultValue(false).build());
    private final Setting<Double> popTextOffset = sgPopText.add(new DoubleSetting.Builder().name("text-offset").description("Height offset.").defaultValue(0.5).min(0).build());
    private final Setting<Double> scale = sgPopText.add(new DoubleSetting.Builder().name("text-scale").description("The scale.").defaultValue(1).min(0).build());
    public final Setting<SettingColor> textColor = sgPopText.add(new ColorSetting.Builder().name("text-color").description("The text color.").defaultValue(new SettingColor(114, 11, 135,75)).build());


    public static final List<Entry> popEntries = new ArrayList<>();
    private final List<Entry> pops = new ArrayList<>();

    public PopESP() { super(Categories.Misc, "pop-esp", "Render ESP where players pop."); }


    @EventHandler
    private void onReceivePacket(PacketEvent.Receive event) {
        if (!(event.packet instanceof EntityStatusS2CPacket p)) return;
        if (p.getStatus() != 35) return;
        if (debug.get()) info("Received pop packet, checking entity");
        Entity entity = p.getEntity(mc.world);
        if (entity.equals(mc.player)) return;
        if (!(entity instanceof PlayerEntity player)) return; // pattern variables are cool thanks IntelliJ
        if (debug.get()) info("Valid PlayerEntity: " + player.getEntityName() + " | Queuing effect");
        add(new Entry(player));
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        for (Entry entry : popEntries) entry.tick(); // handle render time / ascend / fading
    }

    // Render ESP around where the player popped
    @EventHandler
    private void onRender(Render3DEvent event) {
        update();
        if (!pops.isEmpty()) {
            for (Entry entry : pops) {
                PlayerEntity player = entry.e;
                if (!PlayerUtil.isDead(player)) entry.render3D(event);
            }
        }
    }

    // Render the text above the ESP
    @EventHandler
    private void onRender2D(Render2DEvent event) {
        update();
        if (!pops.isEmpty() && renderPopText.get()) {
            for (Entry entry : pops) {
                PlayerEntity player = entry.e;
                if (!PlayerUtil.isDead(player)) entry.render2D(event);
            }
        }
    }


    private void update() {
        ArrayList<Entry> entryRemovalQueue = new ArrayList<>();
        for (Entry entry : popEntries) if (entry.ticksLeft <= 0) entryRemovalQueue.add(entry);
        entryRemovalQueue.forEach(popEntries::remove);
        pops.clear();
        pops.addAll(popEntries);
    }


    private void add(Entry entry) {
        if (deleteOld.get()) popEntries.removeIf(player -> player.uuid.equals(entry.uuid)); // remove existing entry if needed
        popEntries.add(entry);
        // shit code cope
        //ThreadHelper.fixedExecutor.execute(() -> { // remove entry after renderTime has passed
        //    long sleepTime = renderTime.get().longValue() * 1000;
        //    try { Thread.sleep(sleepTime);} catch (InterruptedException ignored) {}
        //    popEntries.remove(entry);
        //});
    }

    private class Entry {
        public final double x;
        public double y;
        public final double z;
        public final double xWidth, zWidth, halfWidth, height;

        public String popText;

        public Color EntrySideColor = new Color(sideColor.get().r, sideColor.get().g, sideColor.get().b, sideColor.get().a);
        public Color EntryLineColor = new Color(lineColor.get().r, lineColor.get().g, lineColor.get().b, lineColor.get().a);

        public final UUID uuid;
        public final String name;
        public final PlayerEntity e;
        public int ticksLeft = MathUtil.intToTicks(renderTime.get());
        public int ticksAscend = 0;
        public int ticksFade = 0;

        public Entry(PlayerEntity entity) {
            halfWidth = entity.getWidth() / 2;
            x = entity.getX() - halfWidth;
            y = entity.getY();
            z = entity.getZ() - halfWidth;
            xWidth = entity.getBoundingBox().getXLength();
            zWidth = entity.getBoundingBox().getZLength();
            height = entity.getBoundingBox().getYLength();
            e = entity;
            uuid = entity.getUuid();
            name = entity.getEntityName();
            int pops = PlayerUtil.getPops(e);
            if (pops < 2) { // grammar momento
                popText = name + " popped " + pops + " time";
            } else {
                popText = name + " popped " + pops + " times";
            }
        }

        public void tick() {
            // Handle render time
            ticksLeft--;
            // Handle ascend
            if (ascend.get()) {
                if (ticksAscend >= ascendTicks.get()) {
                    ticksAscend = 0;
                    y += ascendFactor.get();
                } else {
                    ticksAscend++;
                }
            }
            // Handle fade
            if (fade.get()) {
                if (ticksFade >= fadeTicks.get()) {
                    ticksFade = 0;
                    int alpha = EntrySideColor.a;
                    alpha -= fadeFactor.get();
                    EntrySideColor.a = alpha;
                    EntryLineColor.a = alpha;
                } else {
                    ticksFade++;
                }
            }
        }

        // ESP Rendering
        public void render3D(Render3DEvent event) {
            event.renderer.box(x, y, z, x + xWidth, y + height, z + zWidth, EntrySideColor, EntryLineColor, shapeMode.get(), 0);
        }

        // Pop Text Rendering
        public void render2D(Render2DEvent event) {
            Vec3 pos = new Vec3();
            TextRenderer text = TextRenderer.get();
            double scale = PopESP.this.scale.get();
            pos.set(x + halfWidth, y + height + 0.5 + popTextOffset.get(), z + halfWidth);
            if (!NametagUtils.to2D(pos, scale)) return;
            NametagUtils.begin(pos);
            double i = text.getWidth(popText) / 2.0;
            text.beginBig();
            text.render(popText, -i, 0, textColor.get());
            text.end();
            NametagUtils.end();
        }
    }

}
