package me.ghosttypes.ion.modules.combat;

import me.ghosttypes.ion.modules.render.Notifications;
import me.ghosttypes.ion.utils.Categories;
import me.ghosttypes.ion.utils.Wrapper;
import me.ghosttypes.ion.utils.combat.HoleUtil;
import me.ghosttypes.ion.utils.player.AutomationUtils;
import me.ghosttypes.ion.utils.player.InvUtil;
import me.ghosttypes.ion.utils.player.PlayerUtil;
import me.ghosttypes.ion.utils.world.BlockHelper;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

public class SmartHoleFill extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRange = settings.createGroup("Ranges");
    private final SettingGroup sgPause = settings.createGroup("Pause");
    private final SettingGroup sgRender = settings.createGroup("Pause");


    private final Setting<Boolean> debug = sgGeneral.add(new BoolSetting.Builder().name("debug").defaultValue(false).build());
    private final Setting<CheckMode> fillMode = sgGeneral.add(new EnumSetting.Builder<CheckMode>().name("fill-mode").description("When to fill holes.").defaultValue(CheckMode.Either).build());
    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder().name("fill-delay").description("Delay between filling holes.").defaultValue(1).min(0).sliderMax(10).build());
    private final Setting<Integer> holesPerTick = sgGeneral.add(new IntSetting.Builder().name("holes-per-tick").description("How many holes to fill per tick.").defaultValue(3).min(0).sliderMax(10).build());
    private final Setting<Integer> targetRange = sgGeneral.add(new IntSetting.Builder().name("target-range").description("How far to target players from.").defaultValue(4).min(1).sliderMax(10).build());
    private final Setting<SortPriority> targetPriority = sgGeneral.add(new EnumSetting.Builder<SortPriority>().name("target-priority").description("How to select the player to target.").defaultValue(SortPriority.LowestHealth).build());
    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder().name("rotate").defaultValue(true).build());
    private final Setting<Integer> rotatePrio = sgGeneral.add(new IntSetting.Builder().name("rotate-priority").defaultValue(50).min(1).sliderMax(100).build());

    // Ranges
    private final Setting<Integer> selfHoleRangeH = sgRange.add(new IntSetting.Builder().name("self-range-horizontal").description("Horizontal place range.").defaultValue(4).min(0).sliderMax(10).build());
    private final Setting<Integer> selfHoleRangeV = sgRange.add(new IntSetting.Builder().name("self-range-vertical").description("Vertical place range.").defaultValue(2).min(0).sliderMax(10).build());
    private final Setting<Integer> targetHoleRange = sgRange.add(new IntSetting.Builder().name("target-range").description("How close the target needs to be to the hole.").defaultValue(2).min(0).sliderMax(10).build());

    // Pause
    public final Setting<Boolean> pauseOnEat = sgPause.add(new BoolSetting.Builder().name("pause-on-eat").description("Pauses while eating.").defaultValue(true).build());
    public final Setting<Boolean> pauseOnDrink = sgPause.add(new BoolSetting.Builder().name("pause-on-drink").description("Pauses while drinking.").defaultValue(true).build());
    public final Setting<Boolean> pauseOnMine = sgPause.add(new BoolSetting.Builder().name("pause-on-mine").description("Pauses while mining.").defaultValue(true).build());
    public final Setting<Boolean> pauseOnGap = sgPause.add(new BoolSetting.Builder().name("pause-on-gap").description("Pauses while holding a gap.").defaultValue(false).build());

    // Render
    public final Setting<Boolean> render = sgRender.add(new BoolSetting.Builder().name("render").defaultValue(true).build());
    public final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>().name("shape-mode").defaultValue(ShapeMode.Both).build());
    public final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder().name("side-color").defaultValue(new SettingColor(114, 11, 135,75)).build());
    public final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder().name("line-color").defaultValue(new SettingColor(114, 11, 135)).build());


    private final Setting<Notifications.mode> notifyMode = sgGeneral.add(new EnumSetting.Builder<Notifications.mode>().name("notification-mode").description("How notifications are displayed.").defaultValue(Notifications.mode.Chat).build());


    public SmartHoleFill() {
        super(Categories.Combat, "smart-holefill", "Hole fill but smart");
    }

    private int delayTimer = 0;
    private PlayerEntity target;
    private final ArrayList<BlockPos> renderBlocks = new ArrayList<>();

    @EventHandler
    private void onTick(TickEvent.Post event) {
        FindItemResult obby = InvUtil.findObby();
        if (!obby.found()) {
            error("No obby in hotbar!");
            toggle();
            return;
        }
        // Targeting
        target = TargetUtils.getPlayerTarget(targetRange.get(), targetPriority.get());
        if (TargetUtils.isBadTarget(target, targetRange.get())) target = TargetUtils.getPlayerTarget(targetRange.get(), targetPriority.get());
        if (target == null) {
            renderBlocks.clear();
            return;
        }
        // Pauses
        if (debug.get()) info("Checking pauses");
        if (!shouldFill()) {
            if (debug.get()) info("ShouldFill is false");
            return;
        }
        if (PlayerUtils.shouldPause(pauseOnMine.get(), pauseOnEat.get(), pauseOnDrink.get())) {
            if (debug.get()) info("Pausing on mine/eat/drink");
            return;
        }
        if (PlayerUtil.isHoldingGap() && pauseOnGap.get()) {
            if (debug.get()) info("Pausing on heldGap");
            return;
        }
        delayTimer--;
        if (delayTimer <= 0) {
            delayTimer = delay.get();
            if (debug.get()) info("Getting holes");
            List<BlockPos> holes = HoleUtil.getHoles(mc.player.getBlockPos(), selfHoleRangeH.get(), selfHoleRangeV.get()); // get all nearby holes
            if (debug.get()) info("Starting list size: " + holes.size());
            holes.removeIf(hole -> BlockHelper.distanceBetween(target.getBlockPos(), hole) <= targetHoleRange.get()); // check target distance to hole
            if (debug.get()) info("List size after range check: " + holes.size());
            renderBlocks.addAll(holes);
            int filled = 0;
            for (BlockPos hole : holes) { // iterate through them
                BlockUtils.place(hole, obby, rotate.get(), rotatePrio.get(), true);
                renderBlocks.removeIf(renderBlock -> BlockHelper.getBlock(renderBlock) != Blocks.AIR);
                filled++;
                if (filled >= holesPerTick.get()) break;
            }
        }
    }

    private boolean shouldFill() {
        if (debug.get()) info("Checking should fill");
        CheckMode checkMode = fillMode.get();
        if (checkMode == CheckMode.Either) {
            if (debug.get()) info("Checking mode either");
            if (Wrapper.isInHole(mc.player) || AutomationUtils.isBurrowed(mc.player, false)) return true;
        }
        if (checkMode == CheckMode.Burrowed) {
            if (debug.get()) info("Checking mode burrowed");
            return AutomationUtils.isBurrowed(mc.player, false);
        }
        if (checkMode == CheckMode.InHole) {
            if (debug.get()) info("Checking mode inHole");
            return Wrapper.isInHole(mc.player);
        }
        return false;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (render.get()) {
            renderBlocks.removeIf(renderBlock -> BlockHelper.getBlock(renderBlock) != Blocks.AIR);
            renderBlocks.forEach(blockPos -> event.renderer.box(blockPos, sideColor.get(), lineColor.get(), shapeMode.get(), 0));
        }
    }


    @Override
    public String getInfoString() {
        return EntityUtils.getName(target);
    }

    public enum CheckMode {
        InHole,
        Burrowed,
        Either,
        None
    }

}
