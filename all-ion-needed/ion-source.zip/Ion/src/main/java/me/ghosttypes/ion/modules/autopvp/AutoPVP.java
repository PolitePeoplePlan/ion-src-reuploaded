package me.ghosttypes.ion.modules.autopvp;

import me.ghosttypes.ion.utils.Categories;
import me.ghosttypes.ion.utils.Wrapper;
import me.ghosttypes.ion.utils.world.BaritoneUtil;
import me.ghosttypes.ion.utils.player.PlayerUtil;
import me.ghosttypes.ion.utils.world.BlockHelper;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.movement.Blink;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

public class AutoPVP extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRanges = settings.createGroup("Range");

    // General
    public final Setting<String> targetName = sgGeneral.add(new StringSetting.Builder().name("target").description("The player to target.").defaultValue("YourMom").build());

    // Range
    private final Setting<Integer> targetRange = sgRanges.add(new IntSetting.Builder().name("target-range").description("How far to target the player from.").defaultValue(15).min(0).sliderMax(50).build());
    private final Setting<Integer> targetHoleRangeV = sgRanges.add(new IntSetting.Builder().name("target-hole-range-vertical").description("How close a hole must be to the target.").defaultValue(3).min(0).sliderMax(6).build());
    private final Setting<Integer> targetHoleRangeH = sgRanges.add(new IntSetting.Builder().name("target-hole-range-horizontal").description("How close a hole must be to the target.").defaultValue(4).min(0).sliderMax(6).build());
    private final Setting<Integer> selfHoleRangeV = sgRanges.add(new IntSetting.Builder().name("self-hole-range-vertical").description("How close a hole must be to us (used when target is out of range).").defaultValue(3).min(0).sliderMax(6).build());
    private final Setting<Integer> selfHoleRangeH = sgRanges.add(new IntSetting.Builder().name("self-hole-range-horizontal").description("How close a hole must be to us (used when target is out of range).").defaultValue(4).min(0).sliderMax(6).build());



    public final Setting<SortPriority> priority = sgGeneral.add(new EnumSetting.Builder<SortPriority>().name("target-priority").description("How to filter the players to target.").defaultValue(SortPriority.LowestHealth).build());
    private final Setting<Boolean> useBlink = sgGeneral.add(new BoolSetting.Builder().name("blink-while-pathing").description("Use blink while pathing.").defaultValue(false).build());
    private final Setting<Boolean> debug = sgGeneral.add(new BoolSetting.Builder().name("debug").description("debug msgs.").defaultValue(false).build());


    private PlayerEntity target;
    private BlockPos currentGoal;
    private int blinkTimer, debugTimer;
    private boolean targeting, pathingToSafeHole;



    public AutoPVP() {
        super(Categories.Misc, "auto-pvp", "Maximum trolliage.");
    }


    @Override
    public void onActivate() {
        target = null;
        currentGoal = null;
        blinkTimer = 0;
        targeting = false;
        pathingToSafeHole = false;
    }

    @Override
    public void onDeactivate() {
        resetEverything();
    }


    @EventHandler
    private void onTick(TickEvent.Post event) {

        // Getting target
        target = PlayerUtil.getPlayerByName(targetName.get());
        targeting = !TargetUtils.isBadTarget(target, targetRange.get());

        if (debug.get()) {
            if (targeting) info("Targeting = true");
            if (!targeting) info("Targeting = false");
        }

        // Blink handler
        if (BaritoneUtil.hasGoal()) {
            Blink blink = Modules.get().get(Blink.class);
            if (useBlink.get()) {
                if (!blink.isActive()) {
                    if (debug.get()) info("Activating blink");
                    blink.toggle();
                    blinkTimer = 0;
                } else {
                    blinkTimer++;
                    if (blinkTimer >= 100) {
                        if (debug.get()) info("Deactivating blink");
                        blink.toggle();
                    }
                }
            }
        } else {
            Blink blink = Modules.get().get(Blink.class);
            if (blink.isActive()) {
                if (debug.get()) info("Deactivating blink");
                blink.toggle();
            }
        }

        // Pathing handler
        if (targeting && !pathingToSafeHole) { // first check our target, and make sure we aren't overriding to a safe hole
            if (debug.get()) info("We are targeting");
            if (BaritoneUtil.hasGoal()) { // check if we have a goal hole to path to
                if (debug.get()) info("We have an active target goal");
                if (BaritoneUtil.isAtGoal(currentGoal)) {
                    if (debug.get()) info("We arrived at the target goal, resetting");
                    resetPathing(); // check if we are there
                } else {
                    if (debug.get()) info("We are not at the target goal yet");
                }
            } else { // find a goal hole if we don't have one yet
                if (debug.get()) info("No active goal, checking");
                if (needsRepathToTarget()) { // check where we are now + distance to the target to decide if we need a new goal
                    if (debug.get()) info("We need to re-path to the target");
                    resetPathing();
                    BlockPos hole = HoleParser.getHoleNearTarget(target, targetHoleRangeH.get(), targetHoleRangeV.get()); // look for a hole near the target
                    if (hole == null) { // fallback to a safe hole if there is no path available
                        if (debug.get()) info("Unable to find a valid hole to the target, falling back to safe-hole");
                        resetPathing();
                        pathingToSafeHole = true;
                    } else {
                        if (debug.get()) info("Hole located, setting goal + pathing");
                        currentGoal = hole; // set our current goal + start pathing to it
                        BaritoneUtil.pathToBlockPos(currentGoal);
                    }
                    return;
                } else {
                    if (debug.get()) info("Current target hole position is valid , no need to re-path");
                    resetPathing();
                }
            }
        }

        if (pathingToSafeHole || !targeting) { // next check if we need to path to a safe hole
            if (debug.get()) info("We are pathing to a safe hole");
            if (BaritoneUtil.hasGoal()) { // check if we have a goal safe hole
                if (debug.get()) info("We have an active safe goal");
                if (BaritoneUtil.isAtGoal(currentGoal)) { // check if we are there
                    if (debug.get()) info("We arrived at the safe goal, resetting");
                    resetPathing();
                }
            } else {
                if (needsRepathToSafeHole()) { // check if we need to re-path
                    if (debug.get()) info("We need to re-path to a safe hole");
                    BlockPos safeHole = HoleParser.getSafeHole(selfHoleRangeH.get(), selfHoleRangeV.get()); // find a safe hole
                    if (safeHole != null) { // verify
                        if (debug.get()) info("Hole located, setting goal + pathing");
                        currentGoal = safeHole; // set current goal + path to it
                        BaritoneUtil.pathToBlockPos(currentGoal);
                    } else {
                        if (debug.get()) info("Unable to find a valid safe hole");
                    }
                } else {
                    if (debug.get()) info("Current safe hole position is valid , no need to re-path");
                    pathingToSafeHole = false;
                    resetPathing();
                }
            }
        }
    }


    private boolean needsRepathToTarget() {
        return !Wrapper.isInHole(mc.player) || !(BlockHelper.distanceBetween(mc.player.getBlockPos(), target.getBlockPos()) <= 4);
    }

    private boolean needsRepathToSafeHole() {
        return !Wrapper.isInHole(mc.player);
    }

    private void resetPathing() {
        // Tell the pathing handler we are done pathing, and reset the baritone goal block
        Blink blink = Modules.get().get(Blink.class);
        if (blink.isActive()) blink.toggle();
        BaritoneUtil.forceStopPathing();
        currentGoal = null;
    }

    private void resetEverything() {
        target = null;
        targeting = false;
        resetPathing();
    }


}
