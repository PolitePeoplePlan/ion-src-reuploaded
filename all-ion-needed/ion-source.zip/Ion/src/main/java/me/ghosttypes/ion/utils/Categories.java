package me.ghosttypes.ion.utils;

import meteordevelopment.meteorclient.systems.modules.Category;
import net.minecraft.item.Items;


public class Categories {

    public static final Category Combat = new Category("Ion", Items.BLUE_CANDLE.getDefaultStack());
    public static final Category Chat = new Category("Ion Chat", Items.BLUE_CANDLE.getDefaultStack());
    public static final Category Misc = new Category("Ion Misc", Items.BLUE_CANDLE.getDefaultStack());

}
