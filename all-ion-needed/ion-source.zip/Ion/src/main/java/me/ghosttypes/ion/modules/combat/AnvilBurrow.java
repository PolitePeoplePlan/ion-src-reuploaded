package me.ghosttypes.ion.modules.combat;

import me.ghosttypes.ion.utils.Wrapper;
import me.ghosttypes.ion.utils.player.InvUtil;
import me.ghosttypes.ion.utils.world.BlockHelper;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.AnvilBlock;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.util.math.BlockPos;

public class AnvilBurrow extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> placeDelay = sgGeneral.add(new IntSetting.Builder().name("place-delay").description("Delay between anvil placement.").defaultValue(3).min(1).sliderMax(10).build());
    private final Setting<Boolean> doublePlace = sgGeneral.add(new BoolSetting.Builder().name("double-place").description("Place at your feet and head.").defaultValue(false).build());
    private final Setting<Boolean> doublePlaceInstant = sgGeneral.add(new BoolSetting.Builder().name("instant-double-place").description("Place both anvils at once (this will override persist).").defaultValue(false).build());
    private final Setting<Boolean> onlyInHole = sgGeneral.add(new BoolSetting.Builder().name("only-in-holes").description("Only burrow in a hole.").defaultValue(false).build());
    private final Setting<Boolean> persist = sgGeneral.add(new BoolSetting.Builder().name("persist").description("Replace mined anvils.").defaultValue(false).build());

    private int timer;
    private boolean didInstant;
    public AnvilBurrow() { super(Categories.Combat, "anvil-burrow", "Burrow but with anvils."); }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        if (event.screen instanceof AnvilScreen) event.cancel();
    }


    @Override
    public void onActivate() {
        timer = 0;
        didInstant = false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (onlyInHole.get() && !Wrapper.isInHole(mc.player)) {
            error("You're not in a hole!");
            toggle();
            return;
        }
        if (isComplete()) {
            if (doublePlaceInstant.get()) didInstant = true;
            if (!persist.get()) {
                toggle();
                return;
            }
        }
        if (doublePlaceInstant.get()) {
            if (didInstant) {
                toggle();
            } else {
                placeAnvil(mc.player.getBlockPos().up(2), true);
            }
            return;
        } else {
            if (timer <= 0) {
                timer = placeDelay.get();
                if (!(BlockHelper.getBlock(mc.player.getBlockPos()) instanceof AnvilBlock)) {
                    placeAnvil(mc.player.getBlockPos().up(2), false);
                    return;
                }
                if (!(BlockHelper.getBlock(mc.player.getBlockPos().up()) instanceof AnvilBlock) && doublePlace.get()) {
                    placeAnvil(mc.player.getBlockPos().up(2), false);
                    return;
                }
            } else {
                timer--;
            }
        }
    }


    private void placeAnvil(BlockPos pos, boolean instant) {
        if (instant) {
            BlockUtils.place(pos, InvUtil.findAnvil(), false, 0);
            BlockUtils.place(pos.up(1), InvUtil.findAnvil(), false, 0);
        } else {
            BlockUtils.place(pos, InvUtil.findAnvil(), false, 0);
        }
    }

    private boolean isComplete() {
        if (!doublePlace.get()) {
            return BlockHelper.getBlock(mc.player.getBlockPos()) instanceof AnvilBlock;
        } else {
            return BlockHelper.getBlock(mc.player.getBlockPos()) instanceof AnvilBlock && BlockHelper.getBlock(mc.player.getBlockPos().up()) instanceof AnvilBlock;
        }
    }
}
