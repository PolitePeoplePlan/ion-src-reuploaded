package me.ghosttypes.ion;


import me.ghosttypes.ion.utils.Categories;
import me.ghosttypes.ion.utils.Wrapper;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.fabricmc.loader.api.FabricLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.lang.invoke.MethodHandles;


public class Ion extends MeteorAddon {
	public static final Logger LOG = LogManager.getLogger();
	public static final String VERSION = "1.1";
    public static final File FOLDER = new File(System.getProperty("user.home"), "Ion");
    public static final File MODFOLDER = new File(FabricLoader.getInstance().getGameDir().toString(), "ion-addon");

	public static void log(String msg) {
        LOG.info("[Ion] " + msg);
    }

	@Override
	public void onInitialize() {
		log("Loading...");
        log("Thank you to everyone who donated to Ion. It was a fun but my time has come - GhostTypes");
		if (!MODFOLDER.exists()) MODFOLDER.mkdirs();
        if (!FOLDER.exists()) FOLDER.mkdirs();
        long startTime = System.currentTimeMillis();

		MeteorClient.EVENT_BUS.registerLambdaFactory("me.ghosttypes.ion", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));
		Wrapper.init(startTime);
	}

	@Override
	public void onRegisterCategories() {
	    Modules.registerCategory(Categories.Combat);
	    Modules.registerCategory(Categories.Chat);
	    Modules.registerCategory(Categories.Misc);
	}
}
