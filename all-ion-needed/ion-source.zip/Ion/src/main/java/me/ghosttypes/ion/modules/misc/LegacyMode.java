package me.ghosttypes.ion.modules.misc;

import me.ghosttypes.ion.utils.Categories;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;

public class LegacyMode extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public LegacyMode() {
        super(Categories.Misc, "legacy-mode", "Modifies some client behavior to work on older versions.");
    }

}
