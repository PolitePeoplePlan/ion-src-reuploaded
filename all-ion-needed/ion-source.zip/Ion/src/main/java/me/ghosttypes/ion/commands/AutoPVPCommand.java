package me.ghosttypes.ion.commands;

import baritone.api.BaritoneAPI;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import me.ghosttypes.ion.modules.autopvp.AutoPVP;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.commands.arguments.PlayerArgumentType;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.swarm.Swarm;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.player.PlayerEntity;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class AutoPVPCommand extends Command {

    public AutoPVPCommand() {
        super("autopvp", "Set autopvp's current target.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("player", PlayerArgumentType.player()).executes(context -> {
            PlayerEntity playerEntity = PlayerArgumentType.getPlayer(context);
            AutoPVP autopvp = Modules.get().get(AutoPVP.class);
            autopvp.targetName.set(playerEntity.getEntityName());
            if (autopvp.isActive()) {
                autopvp.toggle();
                autopvp.toggle();
            } else {
                autopvp.toggle();
            }
            return SINGLE_SUCCESS;
        }));
    }
}
