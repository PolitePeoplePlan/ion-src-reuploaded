# Ion
Ion pvp addon for Meteor Client

From mito: Check out endpoints.txt, contains all auth server api endpoints
