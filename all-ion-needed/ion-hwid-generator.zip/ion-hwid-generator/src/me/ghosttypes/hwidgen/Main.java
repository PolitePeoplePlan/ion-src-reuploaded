package me.ghosttypes.hwidgen;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Main {
    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        String hwid = "";
        try { hwid = getHwid(); } catch (Exception e) { hwid = "Unable to generate hwid!"; }
        JFrame f = new JFrame("Ion HWID");
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JTextField hwidField;
        hwidField = new JTextField(hwid);
        hwidField.setBounds(35,40, 200,30);
        f.add(hwidField);
        f.setSize(300, 150);
        f.setLayout(null);
        f.setVisible(true);
    }


    public static String getHwid() {
        try {
            String raw = System.getProperty("user.name") + java.net.InetAddress.getLocalHost().getHostName() + System.getenv("APPDATA") + "copium";
            return Digest.sha256Hex(raw);
        } catch (Exception ignored) {
            return "Your operating system is not supported!";
        }
    }

}
